"""
Personal Photometry Pipeline Configuation File
2016-11-01, michael.mommert@nau.edu
"""

# Photometry Pipeline
# Copyright (C) 2016  Michael Mommert, michael.mommert@nau.edu

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see
# <http://www.gnu.org/licenses/>.

##### telescope/instrument configurations

# MYTELESCOPE setup parameters
twelveinchccd_param = {
    'telescope_instrument': '12IN/CCD',  # telescope/instrument name
    'telescope_keyword': '12IN_CCD',  # telescope/instrument keyword
    'observatory_code': 'V03',  # MPC observatory code
    'secpix': (0.65, 0.65),  # pixel size (arcsec) before binning

    # image orientation preferences
    'flipx': True,
    'flipy': False,
    'rotate': 0,

    # instrument-specific FITS header keywords
    'binning': ('XBINNING', 'YBINNING'),  # binning in x/y
    'extent': ('NAXIS1', 'NAXIS2'),  # N_pixels in x/y
    'ra': 'OBJCTRA',  # telescope pointing, RA
    'dec': 'OBJCTDEC',  # telescope pointin, Dec
    'radec_separator': ' ',  # RA/Dec hms separator, use 'XXX'
    # if already in degrees
    'date_keyword': 'DATE-OBS',  # obs date/time
    # keyword; use
    # 'date|time' if
    # separate
    'obsmidtime_jd': 'MJD-OBS',  # obs midtime jd keyword
    # (usually provided by
    # pp_prepare
    'object': 'OBJECT',  # object name keyword
    'filter': 'FILTER',  # filter keyword
    #'filter_translations': {'Luminance': 'V'},
    'filter_translations': {'clear': 'V', 'red':'V', 'Luminance':'V'},
    #'filter_translations': {'Red': 'V'},
    # filtername translation dictionary
    'exptime': 'EXPTIME',  # exposure time keyword (s)
    'airmass': 'AIRMASS',  # airmass keyword

    # source extractor settings
    'source_minarea': 3,  # default sextractor source minimum N_pixels #DEF 3.5 (FINAL REG SHOWS UP IN CHECK IMAGE
    'source_snr': 6,  # default sextractor source snr for registration #DEF 2 INITIAL REG (CAN BE LARGER)
    'aprad_default': 3,  # default aperture radius in px #DEF 3 - INITIAL REG (CAN BE LARGER)
    'aprad_range': [1, 30],  # [minimum, maximum] aperture radius (px) #DEF 3-10 (FINAL REG - THESE ARE WHAT IS INCLUDED IN THE FINAL DB 
    'sex-config-file': rootpath + '/setup/12IN_CCD.sex',    
    'mask_file': {},
    #                        mask files as a function of x,y binning

    # scamp settings
    'scamp-config-file': rootpath + '/setup/12IN_CCD.scamp',    
    'reg_max_mag'          : 14,
    'reg_search_radius'    : 0.6, # deg
    'source_tolerance': 'medium',

    # swarp settings
    'copy_keywords': ('TELESCOP,INSTRUME,FILTER,EXPTIME,OBJECT,' +
                      'DATE,TIME-OBS,OBJCTRA,OBJCTDEC,SECPIX,AIRMASS,' +
                      'TEL_KEYW,XBINNING,YBINNING,MIDTIMJD'),
    #                         keywords to be copied in image
    #                         combination using swarp
    'swarp-config-file': rootpath + '/setup/12IN_CCD.swarp',

    # default catalog settings
    'astrometry_catalogs': ['GAIA'],
    #'astrometry_catalogs': ['GAIA'],
    #'photometry_catalogs': ['SDSS-R9', 'APASS9', '2MASS']
     'photometry_catalogs': ['APASS9']
}

##### add telescope configurations to 'official' telescopes.py

implemented_telescopes.append('12IN_CCD')

### translate INSTRUME (or others, see _pp_conf.py) header keyword into
#   PP telescope keyword
# example: INSTRUME keyword in header is 'mytel'
instrument_identifiers['QHY CCD QHY163M-ea87d84'] = '12IN_CCD'

### translate telescope keyword into parameter set defined here
telescope_parameters['12IN_CCD'] = twelveinchccd_param
